<!DOCTYPE html>


<div id="catlist">
		<button id='button1'>cat 1</button>
		<button id='button2'>cat 2</button>
		<button id='button3'>cat 3</button>
		<button id='button4'>cat 4</button>
		<button id='button5'>cat 5</button>
	</div>
	<div class="cat" id="cat1">
		<span class="counter">0</span> clicks
		<br>
   		<img class="clicker" src="..//img/cat_picture1.jpg">
   	</div>
   	<div class="cat" id="cat2">
		<span class="counter">0</span> clicks
		<br>
   		<img class="clicker" src="..//img/cat_picture2.jpeg">
   	</div>
   	<div class="cat" id="cat3">
		<span class="counter">0</span> clicks
		<br>
   		<img class="clicker" src="..//img/cat_picture3.jpeg">
   	</div>
   	<div class="cat" id="cat4">
		<span class="counter">0</span> clicks
		<br>
   		<img class="clicker" src="..//img/cat_picture4.jpeg">
   	</div>
   	<div class="cat" id="cat5">
		<span class="counter">0</span> clicks
		<br>
   		<img class="clicker" src="..//img/cat_picture5.jpeg">
</div>
<script src="../js/catclicker.js"></script>
