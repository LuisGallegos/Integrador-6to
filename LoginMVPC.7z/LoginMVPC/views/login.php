<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<?php include('../views/head.php');?>

<?php
    session_id("active");
    session_start();
    if (!isset($_SESSION["username"])) {
    //If the session is active we send user to the Home page
    } else {
        header("Location: ../views/general.php");
    }
?>

<body  ng-controller="loginController as Contrl" >

    <div class="container">

        <div class="vertical-center ">
            <div class="row">
                <div class="well col-md-3 col-md-offset-4">
                    <form ng-submit="Contrl.postForm()" >
                        <div class="form-group">
                            <h3>Hello there!</h3>
                            <label>Please, enter your personal info below to log in. Or click in Sign Up to create a new user.</label>
                        </div>
                        <div class="form-group">
                        <label>Username</label>
                            <input class="form-control" id="inputUsername" type="text" placeholder="SSO" required ng-model="Contrl.inputData.username"/>
                        </div>
                        <div class="form-group">
                            <label>Password</label>
                            <input class="form-control" id="inputPassword" type="password" placeholder="*********" required ng-model="Contrl.inputData.password"/>
                        </div>
                            <div class="btn-group">
                                <button class="btn btn-primary" type="submit">Log In</button>
                                <button class="btn btn-success" type="button" ng-click="Contrl.signIn()">Sign Up</button>
                            </div>
                        </form>
                    </div>
                </div>
        </div>
    </div>

    <?php include '../views/footer.php';?>
</body>



</html>
