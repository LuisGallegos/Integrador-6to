<html>
<head>
    <meta charset="utf-8">

    <title>Secure Login</title>

    <script src="../components/jquery/jquery.min.js" type="text/javascript"></script>

    <!--Bootstra-->
    <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css" />
    <!--Sweet Alert-->
    <link rel="stylesheet" type="text/css" href="../components/sweetalert-master/sweetalert-master/dist/sweetalert.css">

    <link href="../components/bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">

    <script src="../js/angular.min.js"></script>
    <script src="../js/angular-ui-router.min.js"></script>
    <script src="../js/angular-animate.min.js"></script>

    <!-- MetisMenu CSS -->
    <link href="../components/metisMenu/dist/metisMenu.min.css" rel="stylesheet">

    <!-- Timeline CSS -->
    <link href="../css/timeline.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="../css/sb-admin-2.css" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="../components/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">


</head>
