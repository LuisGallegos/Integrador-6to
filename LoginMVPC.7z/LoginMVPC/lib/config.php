<?php

/*$dbhost = "webdb.mtc.ge.com";
$dbuname = "";
$dbpass = "";
$dbname = "";*/

$dbhost  = "localhost";
$dbuname = "root";
$dbpass  = "";
$dbname  = "login";

?>
